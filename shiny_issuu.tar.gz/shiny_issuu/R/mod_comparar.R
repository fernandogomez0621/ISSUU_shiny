mod_comparar_ui <- function(id) {
  ns <- NS(id)
  tagList(
    tags$div(class = "card-panel mb-3",
      tags$div(class = "card-panel-head", "\ud83d\udd04 Configuraci\u00f3n"),
      tags$div(class = "card-panel-body",
        fluidRow(
          column(4, uiOutput(ns("sel_revistas"))),
          column(4, dateInput(ns("f_ini"), "Desde:", value = "2023-06-01", language = "es")),
          column(4, dateInput(ns("f_fin"), "Hasta:", value = Sys.Date(), language = "es"))))),
    uiOutput(ns("comp_content"))
  )
}

mod_comparar_server <- function(id, df_full) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    output$sel_revistas <- renderUI({
      d <- df_full(); if (is.null(d)) return(NULL)
      revs <- sort(unique(d$revista))
      sel <- if (length(revs) >= 2) revs[1:2] else revs
      selectInput(ns("revistas"), "Revistas (min 2):", choices = revs, selected = sel, multiple = TRUE, width = "100%")
    })

    df_f <- reactive({
      d <- df_full(); r <- input$revistas
      if (is.null(d) || is.null(r) || length(r) < 2) return(NULL)
      d[d$revista %in% r & d$publish_date >= input$f_ini & d$publish_date <= input$f_fin, ]
    })

    metricas_r <- reactive({
      d <- df_f(); if (is.null(d) || nrow(d) == 0) return(NULL)
      d |> dplyr::group_by(Revista = revista) |>
        dplyr::summarise(Pubs = dplyr::n(), Impr = sum(impressions, na.rm = TRUE),
          Lect = sum(reads, na.rm = TRUE), Desc = sum(downloads, na.rm = TRUE),
          Comp = sum(shares, na.rm = TRUE), Clics = sum(clicks, na.rm = TRUE),
          Tasa_Lect = round(sum(reads, na.rm = TRUE) / sum(impressions, na.rm = TRUE) * 100, 2),
          Tiempo = round(mean(avg_time_secs, na.rm = TRUE)), .groups = "drop")
    })

    output$comp_content <- renderUI({
      r <- input$revistas
      if (is.null(r) || length(r) < 2) {
        return(tags$div(class = "alert-box", "\u26a0\ufe0f Selecciona al menos 2 revistas para comparar"))
      }
      tagList(
        tags$div(class = "card-panel mb-3",
          tags$div(class = "card-panel-head", "\ud83d\udcca Tabla comparativa"),
          tags$div(class = "card-panel-body", DT::DTOutput(ns("tbl_comp")))),
        fluidRow(class = "g-3 mb-3",
          column(6, tags$div(class = "card-panel",
            tags$div(class = "card-panel-head d-flex justify-content-between align-items-center",
              tags$span("\ud83d\udcca Comparaci\u00f3n"),
              tags$div(style = "width:180px", selectInput(ns("met_bar"), NULL,
                c("Impresiones" = "Impr", "Lecturas" = "Lect", "Descargas" = "Desc",
                  "Compartidos" = "Comp", "Clics" = "Clics"), width = "100%"))),
            tags$div(class = "card-panel-body", plotly::plotlyOutput(ns("bar_comp"), height = "380px")))),
          column(6, tags$div(class = "card-panel",
            tags$div(class = "card-panel-head", "\ud83c\udf69 Distribuci\u00f3n"),
            tags$div(class = "card-panel-body", plotly::plotlyOutput(ns("pie_comp"), height = "380px"))))),
        fluidRow(class = "g-3",
          column(6, tags$div(class = "card-panel",
            tags$div(class = "card-panel-head", "\ud83d\udce6 Boxplot impresiones"),
            tags$div(class = "card-panel-body", plotly::plotlyOutput(ns("box_comp"), height = "380px")))),
          column(6, tags$div(class = "card-panel",
            tags$div(class = "card-panel-head", "\ud83d\udd78\ufe0f Radar"),
            tags$div(class = "card-panel-body", plotly::plotlyOutput(ns("radar"), height = "380px")))))
      )
    })

    output$tbl_comp <- DT::renderDT({
      m <- metricas_r(); if (is.null(m)) return(NULL)
      DT::datatable(m, options = list(dom = "t", scrollX = TRUE), rownames = FALSE, class = "compact stripe")
    })
    output$bar_comp <- plotly::renderPlotly({
      m <- metricas_r(); met <- input$met_bar; if (is.null(m) || is.null(met)) return(NULL)
      plotly::plot_ly(data = m, x = ~Revista, y = as.formula(paste0("~", met)), type = "bar",
        marker = list(color = "#0D5C63"), text = as.formula(paste0("~", met)), textposition = "outside") |>
        aplicar_layout()
    })
    output$pie_comp <- plotly::renderPlotly({
      m <- metricas_r(); met <- input$met_bar; if (is.null(m) || is.null(met)) return(NULL)
      plotly::plot_ly(values = m[[met]], labels = m$Revista, type = "pie", hole = 0.4, textinfo = "percent+label") |>
        aplicar_layout()
    })
    output$box_comp <- plotly::renderPlotly({
      d <- df_f(); if (is.null(d)) return(NULL)
      plotly::plot_ly(data = d, x = ~revista, y = ~impressions, color = ~revista, type = "box", boxpoints = "all") |>
        aplicar_layout() |> plotly::layout(showlegend = FALSE)
    })
    output$radar <- plotly::renderPlotly({
      d <- df_f(); if (is.null(d)) return(NULL)
      fig <- plotly::plot_ly(type = "scatterpolar", fill = "toself")
      metrics <- c("tasa_lectura", "impressions", "clicks", "reads")
      labels <- c("Tasa Lectura", "Impresiones", "Clics", "Lecturas")
      for (r in unique(d$revista)) {
        sub <- d[d$revista == r, ]
        vals <- sapply(metrics, function(m) {
          v <- sub[[m]]; mn <- min(v, na.rm = TRUE); mx <- max(v, na.rm = TRUE)
          if (mx == mn) 0.5 else (mean(v, na.rm = TRUE) - mn) / (mx - mn)
        })
        fig <- fig |> plotly::add_trace(r = vals, theta = labels, name = r)
      }
      fig |> plotly::layout(polar = list(radialaxis = list(visible = TRUE, range = c(0, 1)))) |>
        aplicar_layout()
    })
  })
}
