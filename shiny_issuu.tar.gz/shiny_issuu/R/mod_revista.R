mod_revista_ui <- function(id) {
  ns <- NS(id)
  tagList(
    tags$div(class="card-panel mb-3",
      tags$div(class="card-panel-head", "\ud83d\udd0d Filtros"),
      tags$div(class="card-panel-body",
        fluidRow(
          column(3, selectInput(ns("revista"), "Revista:", choices=NULL, width="100%")),
          column(3, dateInput(ns("f_ini"), "Desde:", value="2023-06-01", language="es")),
          column(3, dateInput(ns("f_fin"), "Hasta:", value=Sys.Date(), language="es")),
          column(3, selectInput(ns("orden"), "Ordenar por:",
            c("Fecha"="publish_date","Impresiones"="impressions","Lecturas"="reads",
              "Tasa lectura"="tasa_lectura","Tiempo"="avg_time_secs"), width="100%"))))),
    fluidRow(class="g-3 mb-3",
      column(3, uiOutput(ns("k_pubs"))), column(3, uiOutput(ns("k_impr"))),
      column(3, uiOutput(ns("k_reads"))), column(3, uiOutput(ns("k_tasa")))),
    fluidRow(class="g-3 mb-3",
      column(3, uiOutput(ns("k_desc"))), column(3, uiOutput(ns("k_shares"))),
      column(3, uiOutput(ns("k_clicks"))), column(3, uiOutput(ns("k_time")))),
    tags$div(class="card-panel",
      tags$div(class="card-panel-head", "\ud83d\udcdd Publicaciones"),
      tags$div(class="card-panel-body", DT::DTOutput(ns("tbl_pubs"))))
  )
}

mod_revista_server <- function(id, df_full) {
  moduleServer(id, function(input, output, session) {
    observe({
      d <- df_full(); if(is.null(d)) return()
      updateSelectInput(session, "revista", choices=sort(unique(d$revista)))
    })

    df_f <- reactive({
      d <- df_full(); r <- input$revista; if(is.null(d)||is.null(r)||r=="") return(NULL)
      sub <- d[d$revista==r & d$publish_date>=input$f_ini & d$publish_date<=input$f_fin, ]
      ord <- input$orden; if(!is.null(ord)) sub <- sub[order(-sub[[ord]]), ]
      sub
    })

    kpi <- function(emoji,val,lbl,col) tags$div(class="kpi-box",style=paste0("border-top:4px solid ",col),
      tags$div(class="kpi-emoji",emoji),tags$div(class="kpi-val",val),tags$div(class="kpi-lbl",lbl))

    output$k_pubs <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\ud83d\udcda",nrow(d),"Publicaciones","#0D5C63") })
    output$k_impr <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\ud83d\udc41\ufe0f",format(round(mean(d$impressions,na.rm=TRUE)),big.mark=","),"Prom impresiones","#44A1A0") })
    output$k_reads <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\ud83d\udcd6",format(round(mean(d$reads,na.rm=TRUE)),big.mark=","),"Prom lecturas","#F78764") })
    output$k_tasa <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL)
      t<-if(sum(d$impressions,na.rm=TRUE)>0) round(sum(d$reads,na.rm=TRUE)/sum(d$impressions,na.rm=TRUE)*100,2) else 0
      kpi("\ud83c\udfaf",paste0(t,"%"),"Tasa lectura","#0B3954") })
    output$k_desc <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\u2b07\ufe0f",format(round(mean(d$downloads,na.rm=TRUE)),big.mark=","),"Prom descargas","#78C0A8") })
    output$k_shares <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\ud83d\udd17",format(round(mean(d$shares,na.rm=TRUE)),big.mark=","),"Prom compartidos","#0D5C63") })
    output$k_clicks <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\ud83d\udc46",format(round(mean(d$clicks,na.rm=TRUE)),big.mark=","),"Prom clics","#F78764") })
    output$k_time <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL)
      kpi("\u23f1\ufe0f",format_time(mean(d$avg_time_secs,na.rm=TRUE)),"Tiempo prom","#44A1A0") })

    output$tbl_pubs <- DT::renderDT({
      d <- df_f(); if(is.null(d)||nrow(d)==0) return(NULL)
      show <- d[,c("title","edicion","publish_date","impressions","reads","tasa_lectura","downloads","shares","clicks","average_time_spent")]
      names(show) <- c("T\u00edtulo","Ed.","Fecha","Impr","Lect","% Lect","Desc","Comp","Clics","Tiempo")
      DT::datatable(show, options=list(pageLength=15, dom="ftip", scrollX=TRUE), rownames=FALSE, class="compact stripe")
    })
  })
}
