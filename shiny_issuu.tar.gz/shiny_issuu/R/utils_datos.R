cargar_issuu <- function() {
  files <- list.files("data", pattern = "issuu_combined_data_.*\\.csv", full.names = TRUE)
  if (length(files) == 0) return(NULL)
  df <- readr::read_csv(files[1], show_col_types = FALSE)
  df$publish_date <- as.Date(df$publish_date)
  df$year_month <- format(df$publish_date, "%Y-%m")
  df$avg_time_secs <- sapply(df$average_time_spent, parse_time)
  df$tasa_lectura <- ifelse(df$impressions > 0, round(df$reads / df$impressions * 100, 2), 0)
  df$tasa_clicks <- ifelse(df$impressions > 0, round(df$clicks / df$impressions * 100, 2), 0)
  df$tasa_shares <- ifelse(df$impressions > 0, round(df$shares / df$impressions * 100, 2), 0)
  df
}
