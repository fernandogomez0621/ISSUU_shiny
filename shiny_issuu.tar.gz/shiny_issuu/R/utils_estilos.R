COL_PRIMARY <- "#0D5C63"
COL_SECONDARY <- "#44A1A0"
COL_ACCENT <- "#F78764"
COL_DARK <- "#0B3954"
COL_LIGHT <- "#78C0A8"

aplicar_layout <- function(fig, titulo = NULL) {
  fig |> plotly::layout(
    title = list(text = titulo, font = list(size = 13, color = COL_DARK, family = "Inter")),
    font = list(family = "Inter, sans-serif", size = 11, color = COL_DARK),
    hovermode = "x unified",
    legend = list(orientation = "h", yanchor = "bottom", y = 1.02, xanchor = "right", x = 1),
    margin = list(l = 55, r = 25, t = 55, b = 45),
    plot_bgcolor = "#f8faf9", paper_bgcolor = "#ffffff"
  ) |> plotly::config(displayModeBar = TRUE, displaylogo = FALSE)
}

format_time <- function(secs) {
  m <- as.integer(secs %/% 60); s <- as.integer(secs %% 60)
  sprintf("%02d:%02d", m, s)
}

parse_time <- function(x) {
  if (is.na(x) || x == "") return(0)
  if (is.numeric(x)) return(x)
  parts <- strsplit(as.character(x), ":")[[1]]
  if (length(parts) == 2) as.numeric(parts[1]) * 60 + as.numeric(parts[2]) else 0
}
