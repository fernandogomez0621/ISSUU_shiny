mod_resumen_ui <- function(id) {
  ns <- NS(id)
  tagList(
    tags$div(class="card-panel mb-3",
      tags$div(class="card-panel-head d-flex justify-content-between align-items-center",
        tags$span("\ud83d\udcc5 Par\u00e1metros de an\u00e1lisis"),
        tags$div(class="d-flex gap-2",
          tags$div(style="width:150px", dateInput(ns("f_ini"), "Inicio", value="2023-06-01", language="es")),
          tags$div(style="width:150px", dateInput(ns("f_fin"), "Fin", value=Sys.Date(), language="es")),
          tags$div(style="width:200px", selectInput(ns("metrica"), "M\u00e9trica",
            c("Impresiones"="impressions","Lecturas"="reads","Descargas"="downloads",
              "Compartidos"="shares","Clics"="clicks","Tiempo promedio"="avg_time_secs"), width="100%"))))),
    fluidRow(class="g-3 mb-3",
      column(3, uiOutput(ns("k1"))), column(3, uiOutput(ns("k2"))),
      column(3, uiOutput(ns("k3"))), column(3, uiOutput(ns("k4")))),
    fluidRow(class="g-3 mb-3",
      column(3, uiOutput(ns("k5"))), column(3, uiOutput(ns("k6"))),
      column(3, uiOutput(ns("k7"))), column(3, uiOutput(ns("k8")))),
    tags$div(class="card-panel mb-3",
      tags$div(class="card-panel-head", "\ud83d\udcca Resumen por revista"),
      tags$div(class="card-panel-body", DT::DTOutput(ns("tbl_resumen")))),
    fluidRow(class="g-3",
      column(6, tags$div(class="card-panel",
        tags$div(class="card-panel-head", "\ud83d\udcca Comparaci\u00f3n por revista"),
        tags$div(class="card-panel-body", plotly::plotlyOutput(ns("bar_rev"), height="400px")))),
      column(6, tags$div(class="card-panel",
        tags$div(class="card-panel-head", "\ud83d\udcc8 Tendencia"),
        tags$div(class="card-panel-body", plotly::plotlyOutput(ns("line_rev"), height="400px")))))
  )
}

mod_resumen_server <- function(id, df_full) {
  moduleServer(id, function(input, output, session) {
    df_f <- reactive({
      d <- df_full(); if(is.null(d)) return(NULL)
      d[d$publish_date >= input$f_ini & d$publish_date <= input$f_fin, ]
    })

    kpi <- function(emoji, val, lbl, col) {
      tags$div(class="kpi-box", style=paste0("border-top:4px solid ",col),
        tags$div(class="kpi-emoji",emoji), tags$div(class="kpi-val",val), tags$div(class="kpi-lbl",lbl))
    }
    output$k1 <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\ud83d\udcda",nrow(d),"Publicaciones","#0D5C63") })
    output$k2 <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\ud83d\udc41\ufe0f",format(sum(d$impressions,na.rm=TRUE),big.mark=","),"Impresiones","#44A1A0") })
    output$k3 <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\ud83d\udcd6",format(sum(d$reads,na.rm=TRUE),big.mark=","),"Lecturas","#F78764") })
    output$k4 <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\u2b07\ufe0f",format(sum(d$downloads,na.rm=TRUE),big.mark=","),"Descargas","#0B3954") })
    output$k5 <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\ud83d\udd17",format(sum(d$shares,na.rm=TRUE),big.mark=","),"Compartidos","#78C0A8") })
    output$k6 <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL); kpi("\ud83d\udc46",format(sum(d$clicks,na.rm=TRUE),big.mark=","),"Clics","#0D5C63") })
    output$k7 <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL)
      tr <- if(sum(d$impressions,na.rm=TRUE)>0) round(sum(d$reads,na.rm=TRUE)/sum(d$impressions,na.rm=TRUE)*100,1) else 0
      kpi("\ud83c\udfaf",paste0(tr,"%"),"Tasa lectura","#F78764") })
    output$k8 <- renderUI({ d<-df_f(); if(is.null(d)) return(NULL)
      kpi("\u23f1\ufe0f",format_time(mean(d$avg_time_secs,na.rm=TRUE)),"Tiempo prom","#44A1A0") })

    output$tbl_resumen <- DT::renderDT({
      d <- df_f(); if(is.null(d)) return(NULL)
      agg <- d |> dplyr::group_by(revista) |>
        dplyr::summarise(Pubs=dplyr::n(), Impr=sum(impressions,na.rm=TRUE), Lect=sum(reads,na.rm=TRUE),
          Desc=sum(downloads,na.rm=TRUE), Comp=sum(shares,na.rm=TRUE), Clics=sum(clicks,na.rm=TRUE),
          Tasa_Lect=round(sum(reads,na.rm=TRUE)/sum(impressions,na.rm=TRUE)*100,2),
          Tiempo=round(mean(avg_time_secs,na.rm=TRUE)), .groups="drop") |>
        dplyr::arrange(dplyr::desc(Impr))
      DT::datatable(agg, options=list(dom="t", scrollX=TRUE), rownames=FALSE, class="compact stripe")
    })

    output$bar_rev <- plotly::renderPlotly({
      d <- df_f(); m <- input$metrica; if(is.null(d)||is.null(m)) return(NULL)
      agg <- d |> dplyr::group_by(revista, year_month) |> dplyr::summarise(val=sum(.data[[m]],na.rm=TRUE),.groups="drop")
      plotly::plot_ly(data=agg, x=~year_month, y=~val, color=~revista, type="bar",
        text=~format(round(val),big.mark=","), textposition="auto") |>
        aplicar_layout() |> plotly::layout(barmode="group")
    })
    output$line_rev <- plotly::renderPlotly({
      d <- df_f(); m <- input$metrica; if(is.null(d)||is.null(m)) return(NULL)
      agg <- d |> dplyr::group_by(revista, year_month) |> dplyr::summarise(val=sum(.data[[m]],na.rm=TRUE),.groups="drop")
      fig <- plotly::plot_ly()
      for(r in unique(agg$revista)) { sub <- agg[agg$revista==r,]
        fig <- fig |> plotly::add_trace(x=sub$year_month, y=sub$val, type="scatter", mode="lines+markers", name=r) }
      fig |> aplicar_layout()
    })
  })
}
