mod_agente_ui <- function(id) {
  ns <- NS(id)
  tags$div(class="chat-wrap",
    tags$div(class="chat-top",
      tags$div(class="chat-top-left",
        tags$span(class="chat-top-avatar","\ud83e\udd16"),
        tags$div(tags$div(class="chat-top-title","Agente ISSUU"),
          tags$div(class="chat-top-sub","\ud83d\udfe2 Claude Sonnet \u00b7 Bedrock"))),
      actionButton(ns("clear_btn"),"\ud83d\uddd1\ufe0f Limpiar",class="chat-clear-btn")),
    tags$div(class="chat-body",id=ns("chat_area"),uiOutput(ns("chat_history"))),
    tags$div(class="chat-bottom",
      tags$div(class="chat-input-row",
        textInput(ns("user_msg"),NULL,placeholder="Pregunta sobre las publicaciones...",width="100%"),
        actionButton(ns("send_btn"),"\u27a4",class="chat-send-btn")),
      tags$div(class="chat-powered","Powered by Claude \u00b7 Amazon Bedrock")),
    tags$script(HTML(sprintf("$(document).on('keypress','#%s',function(e){if(e.which==13){e.preventDefault();$('#%s').click();}});",ns("user_msg"),ns("send_btn")))))
}

mod_agente_server <- function(id) {
  moduleServer(id, function(input,output,session) {
    historial <- reactiveVal(list())
    sys <- paste(
      "Eres un analista de marketing editorial especializado en metricas de ISSUU.",
      "Datos: 100 publicaciones de revistas tecnicas (2023-2025).",
      "Revistas: Tecnologia del Plastico, Metalmecanica, El Empaque, Reportero Industrial, entre otras.",
      "Metricas: impresiones, lecturas, descargas, compartidos, clics, tiempo de lectura.",
      "Tasa de lectura promedio ~50%. Tecnologia del Plastico lidera en impresiones.",
      "Responde conciso, profesional, en espanol.")

    observeEvent(input$send_btn, {
      msg<-trimws(input$user_msg); if(nchar(msg)==0) return()
      hist<-historial(); hist<-c(hist,list(list(role="user",content=msg)))
      resp<-tryCatch({
        br<-paws::bedrockruntime(config=list(region="us-east-2"))
        msgs<-lapply(hist,function(m) list(role=m$role,content=m$content))
        r<-br$invoke_model(modelId="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
          contentType="application/json",accept="application/json",
          body=charToRaw(jsonlite::toJSON(list(anthropic_version="bedrock-2023-05-31",max_tokens=1000,
            system=sys,messages=msgs),auto_unbox=TRUE)))
        res<-jsonlite::fromJSON(rawToChar(r$body),simplifyVector=FALSE)
        res$content[[1]]$text
      },error=function(e) paste("\u26a0\ufe0f Error:",e$message))
      hist<-c(hist,list(list(role="assistant",content=resp)))
      historial(hist); updateTextInput(session,"user_msg",value="")
    })
    observeEvent(input$clear_btn, { historial(list()) })

    output$chat_history <- renderUI({
      ns<-session$ns; hist<-historial()
      if(length(hist)==0) return(tags$div(class="chat-empty",
        tags$div(class="chat-empty-icon","\ud83e\udd16"),
        tags$div(class="chat-empty-title","Agente de M\u00e9tricas Editoriales"),
        tags$div(class="chat-empty-desc","Pregunta sobre rendimiento, tendencias o comparativas de las revistas."),
        tags$div(class="chat-chips",
          lapply(list("\u00bfQu\u00e9 revista tiene m\u00e1s lectores?","Tendencias 2024","Comparar tasas de lectura","Recomendaciones"),function(q){
            tags$button(class="chat-chip",onclick=sprintf("document.getElementById('%s').value='%s';$('#%s').click();",ns("user_msg"),q,ns("send_btn")),q)}))))
      msgs<-lapply(hist,function(m){
        if(m$role=="user") tags$div(class="msg msg-user",tags$div(class="msg-bubble msg-u",m$content),tags$div(class="msg-av msg-av-u","\ud83d\udc64"))
        else{txt<-gsub("\\*\\*(.+?)\\*\\*","<strong>\\1</strong>",m$content);txt<-gsub("\n","<br/>",txt)
          tags$div(class="msg msg-bot",tags$div(class="msg-av msg-av-b","\ud83e\udd16"),tags$div(class="msg-bubble msg-b",HTML(txt)))}})
      tagList(msgs,tags$script(HTML(sprintf("var ca=document.getElementById('%s');if(ca)ca.scrollTop=ca.scrollHeight;",ns("chat_area")))))
    })
  })
}
