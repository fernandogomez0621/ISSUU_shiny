ui <- fluidPage(
  tags$head(
    tags$link(rel="stylesheet",href="styles.css"),
    tags$link(rel="preconnect",href="https://fonts.googleapis.com"),
    tags$link(rel="stylesheet",
      href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap")),
  tags$nav(class="topbar",
    tags$div(class="topbar-left",
      tags$span(class="topbar-logo","\ud83d\udcda"),
      tags$div(class="topbar-text",
        tags$div(class="topbar-title","ISSUU ANALYTICS"),
        tags$div(class="topbar-sub","M\u00e9tricas de Publicaciones"))),
    tags$span(class="topbar-badge","v1.0")),
  tags$div(class="app-layout",
    tags$aside(class="sidebar",
      tags$div(class="sb-brand",tags$div(class="sb-brand-icon","\ud83d\udcda"),tags$div(class="sb-brand-name","ISSUU Metrics")),
      tags$hr(class="sb-hr"),
      tags$div(class="sb-section","MEN\u00da"),
      tags$a(class="sb-link active",id="nav_resumen",href="#",tags$span(class="sb-emoji","\ud83d\udcca"),"Resumen General"),
      tags$a(class="sb-link",id="nav_revista",href="#",tags$span(class="sb-emoji","\ud83d\udcd6"),"Por Revista"),
      tags$a(class="sb-link",id="nav_comparar",href="#",tags$span(class="sb-emoji","\ud83d\udd04"),"Comparativa"),
      tags$a(class="sb-link",id="nav_agente",href="#",tags$span(class="sb-emoji","\ud83e\udd16"),"Agente IA"),
      tags$hr(class="sb-hr"),
      tags$div(class="sb-section","INFO"),
      uiOutput("sb_stats"),
      tags$div(class="sb-footer",
        tags$div(class="sb-footer-by","Desarrollado por"),
        tags$div(class="sb-footer-name","Andr\u00e9s Fernando G\u00f3mez R."),
        tags$div(class="sb-footer-tech","R \u00b7 Shiny \u00b7 Plotly \u00b7 AWS"))),
    tags$main(class="main-area",
      uiOutput("page_header"),
      uiOutput("page_content"))),
  tags$script(HTML("
    function navTo(id,val){$(document).on('click','#'+id,function(e){
      e.preventDefault();Shiny.setInputValue('nav_click',val,{priority:'event'});
      $('.sb-link').removeClass('active');$(this).addClass('active');});}
    navTo('nav_resumen','resumen');navTo('nav_revista','revista');
    navTo('nav_comparar','comparar');navTo('nav_agente','agente');
  ")))

server <- function(input, output, session) {
  df_full <- reactive({ cargar_issuu() })
  pagina <- reactiveVal("resumen")

  observeEvent(input$nav_click, { pagina(input$nav_click) })

  output$sb_stats <- renderUI({
    d <- df_full(); if(is.null(d)) return(NULL)
    tags$div(class="sb-stats",
      tags$div(class="sb-stat",tags$span(class="sb-stat-l","Publicaciones"),tags$span(class="sb-stat-v",nrow(d))),
      tags$div(class="sb-stat",tags$span(class="sb-stat-l","Revistas"),tags$span(class="sb-stat-v",length(unique(d$revista)))),
      tags$div(class="sb-stat",tags$span(class="sb-stat-l","Impresiones"),tags$span(class="sb-stat-v",format(sum(d$impressions,na.rm=TRUE),big.mark=","))),
      tags$div(class="sb-stat",tags$span(class="sb-stat-l","Per\u00edodo"),tags$span(class="sb-stat-v","2023\u20132025")))
  })

  headers <- list(
    resumen=list(e="\ud83d\udcca",t="Resumen General",d="M\u00e9tricas globales y tendencias de todas las publicaciones"),
    revista=list(e="\ud83d\udcd6",t="Por Revista",d="An\u00e1lisis detallado de publicaciones por revista"),
    comparar=list(e="\ud83d\udd04",t="Comparativa",d="Comparaci\u00f3n entre revistas con radar, boxplot y barras"),
    agente=list(e="\ud83e\udd16",t="Agente IA",d="Consulta con inteligencia artificial"))

  output$page_header <- renderUI({
    h<-headers[[pagina()]]; if(is.null(h)) return(NULL)
    tags$div(class="page-head",
      tags$h1(class="page-title",tags$span(class="page-icon",h$e),h$t),
      tags$p(class="page-desc",h$d))
  })
  output$page_content <- renderUI({
    switch(pagina(),
      "resumen"=mod_resumen_ui("resumen"), "revista"=mod_revista_ui("revista"),
      "comparar"=mod_comparar_ui("comparar"), "agente"=mod_agente_ui("agente"))
  })

  mod_resumen_server("resumen", df_full)
  mod_revista_server("revista", df_full)
  mod_comparar_server("comparar", df_full)
  mod_agente_server("agente")
}

shinyApp(ui, server)
